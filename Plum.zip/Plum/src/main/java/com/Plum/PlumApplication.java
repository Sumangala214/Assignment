package com.Plum;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PlumApplication {

	public static void main(String[] args) {
		SpringApplication.run(PlumApplication.class, args);
	}

}
